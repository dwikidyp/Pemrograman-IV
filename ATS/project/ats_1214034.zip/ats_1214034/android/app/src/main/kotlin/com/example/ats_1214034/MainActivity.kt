package com.example.ats_1214034

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
